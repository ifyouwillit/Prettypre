=== Plugin Name ===
Contributors: ifyouwillit
Donate link: http://prettypre.com/
Tags: pre tag, tags, code tag, custom css, syntax highlighter, css
Requires at least: 3.0.1
Tested up to: 3.9.1
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Plugin to customize the display of the pre tag in WordPress. Easily select a theme for the pre tag and click apply. No need to add any additional information to your custom CSS.

== Description ==

With two clicks, skin the CSS of your pre tags like oldschool operating/hardware terminals and change the size of text. Will add new styles periodically.  You can also select the standard pre CSS format if you choose.  If you have suggestions or would like to contribute, get in touch!

== Installation ==

1. Unzip and upload all files to /wp-content/plugins directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Select your pre style through the options menu on the left navigation.

== Frequently Asked Questions ==

= If I disable the plugin, are the pre styles changed back to the originals? =

Yes

== Screenshots ==

== Changelog ==

= 1.0 =
* The plugin is born!

