<?php header("Content-type: text/javascript"); ?>
var pretag = document.getElementsByTagName("pre");
pretag.classList.add("prettyprint");

